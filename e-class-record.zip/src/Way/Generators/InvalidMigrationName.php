<?php namespace Way\Generators;

class InvalidMigrationName extends \Exception {}
