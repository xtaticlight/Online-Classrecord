<div class="form-group col-lg-4 col-md-4 col-xs-4" style="margin-top: -15px; margin-left: 15px">
    <span id="lblVersion" style="color:#004000;" class="text-nowrap">Build 2015.12.5</span>
    <span id="Label2" class="color1" style="font-family:Bodoni MT;font-size:38pt;">ESOnline</span><br>
    <span id="Label3" class="text-nowrap">Online Class Record Encoding</span>
</div>