<br>
<span class="clTitle">Class Records</span><br>
<span style="font-size:Larger;">2015-2016 - 1st Semester </span>&gt;<span style="font-size:Larger;"> {{$term}}</span>  
<br>
<br>
<div id="table" class="table-responsive">
<form method="post" action="{{ url('/update') }}" id="updateform" >
    
    <div  style="margin:0; overflow-x: scroll;">
    <table  class = "table table-hover">
        
        <tr class = "TableHeader" style="text-transform: capitalize"> 
            <th>ID No.</th>
            <th>Name</th>
            <?php for ($i=0; $i < 5; $i++): ?>
            <?php $count = 0;
                  $end = 'false'; ?>
            @foreach($activitiesData as $data)
            <?php if ($end == 'false'):
            ?>
            @foreach($data as $data1)
            <th>{{$data[$count++]['activities_name']}}</th>
            @endforeach
            <?php endif;
            $end = 'true';
            ?>
            @endforeach
            <?php endfor; ?>
            <th style="background-color: gainsboro;"><a data-toggle = "modal" href="#myModal"><span class="glyphicon glyphicon-plus"></span></a></th>
            <?php $count = 0;
                  $end = 'false'; ?>
            @foreach($activitiesData as $data)
            <?php if ($end == 'false'):
            ?>
            <th>{{$data[0]['term']}} Exam</th>
            <th>{{$data[0]['term']}} Grade</th>
            <?php endif;
            $end = 'true';
            ?>
            @endforeach
            <th>Remarks</th>

        </tr>
        
        <?php $activitiesNo = 1; ?>
        @foreach($activitiesData as $data)
        
        <tr>
             
            <td class="TableHeader" style="background-color: #449d44;" contenteditable="false">{{$data[0]['students_id']}}</td>
            <td style="background-color: #FCFB98; white-space: nowrap;" contenteditable="false">{{$data[0]['students_name']}}</td>
            <?php 
            $count = 1;
            ?>
            <?php for ($i=0; $i < 5; $i++): ?>
            @foreach($data as $data1)
            
            <td><input tabindex="{{$count++}}" style="height: 22px; width: 54px; border: 0" class="form-login" name="{{ $data1['id'] }}" value="{{ $data1['score'] }}"></td>
            <input type="hidden" name="activities{{$activitiesNo}}" value="{{$data1['id']}}" />
            <?php 
                $activitiesNo++;
            ?>
            @endforeach
            <?php endfor; ?>
            <td></td>
            <td style="background-color: #FCFB98;"contenteditable="false" >{{$data[0]['term_exam']}}</td>
            <td  style="background-color: #FCFB98;"contenteditable="false">{{$data[0]['term_grade']}}</td>
            <td  style="background-color: #a9d86e;"contenteditable="true">{{$data[0]['remarks']}}</td>
        </tr>
        @endforeach
        
        <input type="hidden" name="_token" value="{{{ csrf_token() }}}" />
        <input type="hidden" name="activitiesNo" value="{{$activitiesNo}}" />
        <input type="hidden" name="term" value="{{$term}}" />
        <input type="hidden" name="subject_id" value="{{$subject_id}}" />
        
    </table>
    </div>
    <div class = pull-right>
    <button id="export-btn" style="height: 30px;"class="btn btn-info"><span class="glyphicon glyphicon-download-alt"></span> Import</button>
    &nbsp;&nbsp;&nbsp;&nbsp;
    <button id="export-btn" style="height: 30px;"class="btn btn-success"><span class="glyphicon glyphicon-floppy-disk"></span> Save</button>
    &nbsp;&nbsp;&nbsp;&nbsp;
    <button type="button" data-toggle = "modal" data-target = "#myModal1" style  = "height: 30px;" class="btn btn-warning"><span class = "glyphicon glyphicon-open"></span> Post</button>
    </div>
    </form>
    <br>
    <br>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4><span class="glyphicon glyphicon-plus "></span> Add Activity</h4>
            </div>
            <div class="modal-body" style="padding:40px 50px;">
                <form role="form">
                    <div class="form-group col-lg-6">
                        <h5 for="activity"><span class="glyphicon glyphicon-file"></span> Activity Name </h5>

                        <select style = "line-height: 200px;height: 33px;font-size: 13px;">
                            <option>Dropdown to select activity</option>
                            <option>Quiz</option>
                            <option>Oral</option>
                            <option>Assignment</option>
                            <option>Quiz</option>
                            <option>Oral</option>
                            <option>Assignment</option>
                        </select>
                    </div>
                    <div class="form-group col-lg-6">
                        <h5 for="activity"><span class="glyphicon glyphicon-tasks"></span> Total Score </h5>
                        <input type="text" class="form-control" name="type" placeholder="Total Score">
                    </div>
                </form>
            </div>
            <div class = "modal-footer">
                <button Data-dismiss ="modal" class="btn btn-success btn-danger"><span class="glyphicon glyphicon-remove"></span>  Cancel</button>
                <button type="submit" class="btn btn-success btn-success"><span class="glyphicon glyphicon-plus"></span>  Add</button>
            </div>
        </div>

    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header" style="padding:20px 15px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4>Are you sure with this action?</h4>
            </div>
            <div class = "modal-body">
               <p style = "font-size:15px;"> <span class = "glyphicon glyphicon-flash"></span> This will update the data on the prism and it will not be easy.</p>
            </div>
            <div class="modal-footer">
                <button data-dismiss="modal" class="btn btn-success btn-danger"><span class = "glyphicon glyphicon-remove"></span> Cancel</button>
        <button type="submit" class="btn btn-success btn-success"><span class = "glyphicon glyphicon-share"></span> Proceed</button>
      </div>
        </div>

    </div>
</div>

<script>
    $(document).ready(function () {

    });
</script>