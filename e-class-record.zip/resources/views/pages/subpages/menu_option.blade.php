<form method="post" action="./access" id="form1">
    <input type="hidden" name="_token" value="{{{ csrf_token() }}}" />
    <table id="ContentPlaceHolder1_tblMenu" style="margin: -10px; margin-left: 10px">
        <tbody><tr>
                <td style="text-align: center; width: 150px">
                    <input type="image" name="submit" src="./assets/img/classrecord.png" border="0" alt="Submit"/>
                </td>
            </tr>
            <tr>
                <td style="text-align: center; width: 150px;" valign="top">
                    <span id="ContentPlaceHolder1_Label4" style="color:Blue;font-size:14pt;font-weight:normal;">Class Record</span></td>
            </tr>
        </tbody>
    </table>
</form>