
@extends('main')
@section('content')
        <title>Laravel</title>
<div class="title">Welcome to Laravel 5 Toushi!</div>
@stop
