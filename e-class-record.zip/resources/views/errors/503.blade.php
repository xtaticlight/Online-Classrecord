@extends('main')
@section('content')
        <title>Be right back</title>
  <div class="title">Be right back.</div>
@stop
